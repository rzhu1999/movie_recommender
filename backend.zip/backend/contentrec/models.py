from django.db import models


# class Contentrec(models.Model):
# 	movieid = models.CharField(max_length=100)
# 	title = models.CharField(max_length=100)
# 	poster_path = models.CharField(max_length=100)
# 	genres = models.CharField(max_length=100)


# 	def __str__(self):
# 		return self.title